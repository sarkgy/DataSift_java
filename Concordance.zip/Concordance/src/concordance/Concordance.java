/*
 * Concordance class
 * 
 * It reads document(s) from the standard input (stdin), while it is not stopped. 
 *    The document is being read by one line at a time 
 *    and a concordance is generated every time and printed on stdout.
 *
 * Alternative version:
 * The full document is being read while a specific character sequence is not
 *    appeared and then the document is processed and printed on stdout once.
 */

package Concordance;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Gyorgy Sarkany
 */
public class Concordance {

    /**
     * @param args No arguments used
     */
    public static void main(String[] args) {
        
        String document = "";
        
        BufferedReader buffReader = new BufferedReader(new InputStreamReader(System.in));
        String line;
        try {
            while ((line = buffReader.readLine())!=null) {
                document = document.concat(line + " ");
                MakeConcordance(document);
            }
        }
        catch (IOException ioe) {
            System.out.println("IO error:" + ioe);
        }
        finally {
            try {
                buffReader.close();
            }
            catch (IOException exc) {
                System.out.println("Closing buffered reader error: " + exc);
            }
        }
        
        // alternative version where until the "#*!*#*!*#" character sequence 
        //    will not be read, everything is stored for processing
        /*try {
            while (!(line = buffReader.readLine()).equals("#*!*#*!*#")) {
                document = document.concat(line + " ");
            }
            MakeConcordance(document);
        }
        catch (IOException ioe) {
            System.out.println("IO error:" + ioe);
        }
        finally {
            try {
                buffReader.close();
            }
            catch (IOException exc) {
                System.out.println("Closing buffered reader error: " + exc);
            }
        }*/
        
        // alternative version, using Scanner class which handles IO Exceptions
        /*String line;
        Scanner stdin = new Scanner(System.in);
        while (stdin.hasNextLine()) {
            line = stdin.nextLine();
            document = document.concat(line);
            MakeConcordance(document);
        }*/
    }
    
    /**
     * @param document
     * The document which has been read will be processed to make concordance.
     * 
     * no return value
     * It will create the concordance and print it.
     */
    private static void MakeConcordance(String document) {
        
        String myDocument = Clean(document);
        
        List<ConcElement> concordance;
        concordance = Store(myDocument);
        
        for (ConcElement con : concordance)
            System.out.println(con.toString());
    }
    
    /**
     * It will remove all signs from the doc parameter except the sentence 
     *    ending ones (.? and !) and the word connecting sings (- and ').
     * 
     * @param doc
     * Document with full punctuation
     * @return 
     * Document with sentence ending punctuation and word connecting signs only.
     */
    private static String Clean(String doc) {
        
        String cleanDoc = doc.replaceAll("[\\p{Punct}&&[^\\.|^\\?|^\\!|^\\-|^']]", " ");
        cleanDoc = cleanDoc.replace("...", " ");
        return cleanDoc;
    }
    
    /**
     * The method will store the document in a concordance in alphabetic order.
     *
     * @param doc
     * Document required to create a concordance from.
     * @return List<ConcElement>
     * A list with the element of the concordance. 
     */
    private static List<ConcElement> Store(String doc) {
        
        int noOfSentence = 0;
        List<ConcElement> conc = new LinkedList<ConcElement>();
        String[] words = doc.split(" +");
        
        int noOfWords = words.length;
        for (int i = 0; i < noOfWords; i++) {
            // only punctuations - no word character(s)
            if (words[i].matches("\\W+")) {
                if (((i+1) < noOfWords) && words[i+1].matches("[A-Z].*")) {
                    noOfSentence++;
                } 
            }
            // words ending with . ? or ! character(s)
            else if (words[i].endsWith(".") || words[i].endsWith("?") || words[i].endsWith("!")) {
                // abbreviations - ending with full stop (.)
                if (((i+1) < noOfWords) && words[i+1].matches("[a-z].*")) {
                    InsertConc(conc, words[i], noOfSentence);
                }
                else {
                    // removing punctuation signs
                    char[] characters = words[i].toCharArray();
                    int j = words[i].length()-1;
                    while (characters[j] == '.' || characters[j] == '?' || characters[j] == '!') {
                        j--;
                    }
                    String wordOnly = words[i].substring(0, j+1);
                    InsertConc(conc, wordOnly, noOfSentence);
                    // if end of sentence
                    if (((i+1) < noOfWords) && words[i+1].matches("[A-Z].*")) {
                        noOfSentence++;
                    }
                }
            }
            else {
                InsertConc(conc, words[i], noOfSentence);
            }
        }
        // alphabetic sorting of concordance
        conc.sort(new Comparator<ConcElement>()
                 {
                     @Override
                     public int compare(ConcElement c1, ConcElement c2)
                     {
                         return c1.getWord().compareTo(c2.getWord());
                     }        
                 });
        return conc;
    }
    
    /**
     * @param List<ConcElement> conc, String word, int noOfSentence
     * List of concordance (conc), the word and the sentence which the word
     *    has been found. 
     * Sentences started with zero-index.
     * 
     * No return value.
     */
    private static void InsertConc(List<ConcElement> conc, String word, int noOfSentence) {
        
        word = word.toLowerCase();
        if (conc.isEmpty()) {
            conc.add(new ConcElement(word, noOfSentence));
        }
        else {
            boolean exist = false;
            for ( ConcElement tempConc : conc) {
                if (tempConc.getWord().equals(word)) {
                    tempConc.addSentence(noOfSentence);
                    exist = true;
                }
            }
            if (!exist)
                conc.add(new ConcElement(word, noOfSentence));
        }
    }
}
