/*
 * ConcElement class
 * 
 * One element of the concordance which has the word and the sentences 
 *    in which the word can be found.
 * 
 *
 */

package Concordance_2;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Gyorgy Sarkany
 */
public class ConcElement {
    
    /**
     * @variable: word sentences
     */
    private String word;
    private List<Integer> sentences;
    
    // create a new element with initial page number
    public ConcElement(String word, int page) {
        this.word = word;
        this.sentences = new ArrayList<Integer>();
        this.sentences.add(page);
    }
    
    // return the word of the element
    public String getWord() {
        return this.word;
    }
    
    // return all the sentences of the element
    public List<Integer> getSentences() {
        return this.sentences;
    }
    
    // add sentence number to the existing element
    public void addSentence(int sentence) {
        this.sentences.add(sentence);
    }
    
    /**
     * Returns the concordance element in the required form.
     * @return String
     */
    @Override
    public String toString() {
        String sentence = this.getSentences().get(0).toString();
        int pageNumber = this.getSentences().size();
        if (pageNumber > 1)
            for (int i=1; i<pageNumber; i++)
                sentence = sentence.concat("," + this.getSentences().get(i));
        return this.getWord() + " {" + this.getSentences().size() + ":" + sentence + "}";
    }
}
